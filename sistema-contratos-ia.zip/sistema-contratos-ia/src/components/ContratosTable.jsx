export default function ContratosTable({ contratos, setContratos }) {

  function excluir(id) {
    const novaLista = contratos.filter(c => c.id !== id)

    setContratos(novaLista)

    localStorage.setItem(
      'contratosIA',
      JSON.stringify(novaLista)
    )
  }

  return (
    <div style={{
      background:'#0f172a',
      padding:'20px',
      borderRadius:'20px'
    }}>
      <h2>Contratos</h2>

      <table width="100%" style={{marginTop:'20px'}}>
        <thead>
          <tr style={{textAlign:'left'}}>
            <th>Empresa</th>
            <th>Projeto</th>
            <th>Valor</th>
            <th>Status</th>
            <th>Ações</th>
          </tr>
        </thead>

        <tbody>
          {contratos.map((contrato) => (
            <tr key={contrato.id}>
              <td>{contrato.empresa}</td>
              <td>{contrato.projeto}</td>
              <td>{contrato.valor}</td>
              <td>{contrato.status}</td>

              <td>
                <button
                  onClick={() => excluir(contrato.id)}
                  style={{
                    background:'#dc2626',
                    border:'none',
                    color:'white',
                    padding:'8px 12px',
                    borderRadius:'8px'
                  }}
                >
                  Excluir
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
