import { useRef, useState } from 'react'
import { extrairDadosContrato } from '../services/parserContrato'

export default function UploadContrato({ contratos, setContratos }) {
  const inputRef = useRef(null)
  const [arquivoNome, setArquivoNome] = useState('')

  async function handlePDF(event) {
    const file = event.target.files[0]

    if (!file) return

    setArquivoNome(file.name)

    const dados = await extrairDadosContrato(file)

    const novoContrato = {
      id: Date.now(),
      ...dados
    }

    const lista = [novoContrato, ...contratos]

    setContratos(lista)

    localStorage.setItem(
      'contratosIA',
      JSON.stringify(lista)
    )
  }

  return (
    <div style={{
      background:'#0f172a',
      padding:'20px',
      borderRadius:'20px'
    }}>
      <h2>Upload Inteligente</h2>

      <input
        ref={inputRef}
        type="file"
        accept="application/pdf"
        style={{display:'none'}}
        onChange={handlePDF}
      />

      <button
        onClick={() => inputRef.current.click()}
        style={{
          background:'#2563eb',
          color:'white',
          border:'none',
          padding:'12px 20px',
          borderRadius:'10px',
          marginTop:'20px'
        }}
      >
        Selecionar PDF
      </button>

      <p style={{marginTop:'15px', color:'#94a3b8'}}>
        {arquivoNome}
      </p>
    </div>
  )
}
