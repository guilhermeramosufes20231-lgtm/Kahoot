import { useState } from 'react'
import UploadContrato from './UploadContrato'
import ContratosTable from './ContratosTable'

export default function Dashboard() {
  const [contratos, setContratos] = useState([])

  return (
    <div style={{padding:'40px', maxWidth:'1200px', margin:'0 auto'}}>
      <h1 style={{fontSize:'38px'}}>Sistema Gestão Contratual IA</h1>
      <p style={{color:'#94a3b8'}}>
        Upload inteligente de contratos PDF
      </p>

      <div style={{
        display:'grid',
        gridTemplateColumns:'2fr 1fr',
        gap:'20px',
        marginTop:'30px'
      }}>
        <ContratosTable
          contratos={contratos}
          setContratos={setContratos}
        />

        <UploadContrato
          contratos={contratos}
          setContratos={setContratos}
        />
      </div>
    </div>
  )
}
