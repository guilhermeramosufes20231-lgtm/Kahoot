export async function extrairDadosContrato(file) {

  const nome = file.name.replace('.pdf', '')

  return {
    empresa: detectarEmpresa(nome),
    projeto: nome,
    valor: 'R$ 0,00',
    status: 'PDF processado pela IA'
  }
}

function detectarEmpresa(texto) {
  const lower = texto.toLowerCase()

  if (lower.includes('vale')) return 'Vale S.A.'
  if (lower.includes('petrobras')) return 'Petrobras'
  if (lower.includes('ufes')) return 'UFES'

  return 'Empresa não identificada'
}
